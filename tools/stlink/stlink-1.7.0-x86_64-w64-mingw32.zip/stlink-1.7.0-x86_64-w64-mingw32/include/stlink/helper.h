#ifndef SYS_HELPER_H
#define SYS_HELPER_H

unsigned time_ms();

int arg_parse_freq(const char *str);

#endif /* SYS_HELPER_H */
